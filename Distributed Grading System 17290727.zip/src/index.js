import React, {useEffect} from 'react';
import ReactDOM from 'react-dom/client';
import 'semantic-ui-css/semantic.min.css';
import { BrowserRouter as Router,
        Route,
        Routes,
        } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import './index.css';
import App from './App';
import Login from './Components/auth/Login';
import SingUp from './Components/auth/SingUp';
import firebase from './firebase';
import store from './Store/store';
import { Provider, useSelector } from 'react-redux';
import { useFirebaseConnect, ReactReduxFirebaseProvider, firebaseReducer, isLoaded, isEmpty } from 'react-redux-firebase';
import PrivateRoot from './Components/auth/PrivateRoot';


const rrProps = {
  firebase,
  config: {
    userProfile: 'users',
  },
  dispatch: store.dispatch,
}

const Root = () => {
  const navigate = useNavigate();

  useFirebaseConnect([ { path: `courses/assignments`,
                            } ]);
  //Burada hoca tarafından gönderilen herbir assignment için IsDistributed 
  //değeri atayacağız. Bu değerlerin hepsi başlangıçta false olacak.
  //öncelikle her bir assignment a erişelim:
  const courses = useSelector(state => state.firebase.data.courses);


  useEffect(() => {
    firebase.auth().onAuthStateChanged((user) => {
      if(user) {
        //login
        navigate('/')
      }
      else {
        //logout
        navigate('/login')
  }})
    }, [])
  return(
    <Routes>
      <Route element={<PrivateRoot />} >
        <Route path="/" navigate element={<App />} />
          </Route>

      <Route path="/login" navigate element={<Login />} />
      <Route path="/signup" navigate element={<SingUp />} />
  </Routes>)

};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<Provider store={store}>
  <ReactReduxFirebaseProvider {...rrProps}>
    <Router>
      <Root />
    </Router>
  </ReactReduxFirebaseProvider>
</Provider>
);
