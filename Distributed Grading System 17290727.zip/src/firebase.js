import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/database";
import "firebase/compat/storage";


const firebaseConfig = {
    apiKey: "AIzaSyAGpWgwQujS2U19DyMNCHM4M9jDwWJmx8Q",
    authDomain: "chatify-802ce.firebaseapp.com",
    projectId: "chatify-802ce",
    storageBucket: "chatify-802ce.appspot.com",
    messagingSenderId: "1063339881780",
    appId: "1:1063339881780:web:31c250224dec0e7dac2161",
    measurementId: "G-7L3KDNYMZT"
  };

    firebase.initializeApp(firebaseConfig);

export default firebase;