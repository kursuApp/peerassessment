import React from "react";
import { Button, Grid, Sidebar } from "semantic-ui-react";
import { useSelector } from "react-redux";
import SidePanel from "./Components/SidePanel/SidePanel";
import CoursePanel from "./Components/ChatPanel/CoursePanel";


const App = () => {

  const currentChannel = useSelector((state) => state.channels.currentChannel);

  return (
    <Grid columns="2" style = {{ background: "#f00", //hegiht full
                                margin: 0,
                                padding: 0,
                                height: "100vh",
                                overflowY: "auto",

    }}>
      <Grid.Column width="3" style = {{ background: "#fff", //hegiht full
                                margin: 0,
                                padding: 0,
                                height : "100vh",
                                overflowY: "auto",

    }}>
        {/* sidebar */}
        <SidePanel />
      </Grid.Column>
      <Grid.Column width="13" style = {{ background: "#fff", //hegiht full
                                margin: 0,
                                padding: 0,
                                overflowY: "auto",

    }}>
        {/* course screen */}
        <CoursePanel currentChannel={currentChannel} 
        />
      </Grid.Column>
    </Grid>

  );
}

export default App;
