import { SET_CURRENT_COURSE } from './types';

export const setCurrentCourse = (course) => {
    return {
        type: SET_CURRENT_COURSE,
        payload: course
    };
};