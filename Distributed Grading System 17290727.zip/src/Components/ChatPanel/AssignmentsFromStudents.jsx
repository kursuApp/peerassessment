//Burada firebase'den gelen verileri kullanarak öğrencilerin gönderdiği ödevleri listeliyoruz.
//Bu component her bir assignment için bir kutu oluşturacak ve bunu alt alta sıralayacak. Kutunun sol tarafına öğrenci adı, sağ tarafına ödevin url bağlantısına gidecek bir buton olacak.

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useFirebaseConnect, isLoaded, isEmpty } from 'react-redux-firebase';
import { Button, Form, Input, TextArea, Message, Icon, Modal, Menu } from 'semantic-ui-react';
import { v4 as uuidv4 } from 'uuid';
import { useFirebase } from 'react-redux-firebase';
import { Link } from 'react-router-dom';

const AssignmentsFromStudents = (assignmentID) => {
    const firebase = useFirebase();
    const profile = useSelector(state => state.firebase.profile);
    const currentUserUid = useSelector(state => state.firebase.auth.uid);
    const userType = useSelector(state => state.firebase.profile.userType);
    useFirebaseConnect([ { path: `courses/assignments/${assignmentID.assignmentID}`,
                            storeAs: 'uploadedAssignment' } ]);
    
    useFirebaseConnect([ { path: `users`} ]);                        

    const uploadedAssignment = useSelector(state => state.firebase.data.courses.assignments[assignmentID.assignmentID].homeworkAttenders);

    const userData = useSelector(state => state.firebase.data?.users);

    const [gradeFromTeacher, setGradeFromTeacher] = useState(0);
    
    const getUseName = (uid) => {
        return userData?.[uid]?.name
    }

    let currentHasHomeWork = false;

    let comp = false

    const downloadHomework = (Links) => {
        window.open(Links, '_blank');
    }
    const currentAssignment = useSelector(state => state.firebase.data.courses?.assignments?.[assignmentID.assignmentID]);

    const findHomeworkByUserId = (userId) => {
        //Bu user id ye sahip ödevi çekiyoruz:
        
        if (isLoaded(currentAssignment))
        {
            downloadHomework(Object.values(currentAssignment?.homeworkAttenders?.[userId])[0].homeworkFileUrl);
        }
        
    }

    if (isLoaded(uploadedAssignment))
    {
        for (const attendee of Object.keys?.(uploadedAssignment)) {
        
            if (currentUserUid == attendee) {
                currentHasHomeWork = true;
            }
            
        }
    }

    const handleChange = (e) => {
        setGradeFromTeacher(e.target.value);
    }

    const gradeByTeacher = (userId) => {

        //kullanıcının userid si ile birlikte 
        firebase.update(`courses/assignments/${assignmentID.assignmentID}/homeworkAttenders/${userId}`, { gradeFromTeacher: gradeFromTeacher });
        firebase.update(`courses/assignments/${assignmentID.assignmentID}/homeworkAttenders/${userId}`, { regradedState: true });
        console.log("grade from teacher: ", gradeFromTeacher);
        //setGradeFromTeacher(0);
    }
    return (
        
        <Menu.Menu>
             <div style={{overflow: 'auto', maxHeight: '200px'}}>

            {   
                //if usertype student and current user has homework true, then return the homework
                userType == "student" && currentHasHomeWork == true && (
                    comp =true,
                    
                    
                        <Button
                            name="My Homework"
                            as="a"
                            icon="file"
                            style={{
                                backgroundColor: "#121212",
                                borderRadius: 5,

                                padding: "5px 15px",
                                fontSize: "1.2em",
                                color: "white",
                            }}
                            onClick={() => findHomeworkByUserId(currentUserUid)}> My Homework

                        </Button>
                )

            }
                <table style={{ backgroundColor: "gray" }}>
                    
            {uploadedAssignment && !comp &&
                Object.keys(uploadedAssignment).map((key) => {
                     return (
                        
                        <tbody>
                             <thead>
                                 <tr>
                                     <th>Homeworks</th>
                                     <th>Objections</th>
                                 </tr>
                             </thead>
                        <tr>
                        <td>

                        <Button style = {{backgroundColor: "#faf"}} onClick={() => findHomeworkByUserId(key)}
                        >{getUseName(key)}</Button>

                        </td>
                        <td>
                        
                        <Button disabled = {uploadedAssignment[key]?.regradedState == undefined || uploadedAssignment[key]?.regradedState} >Regrade</Button>
                        </td>

                        <td>
                        <input disabled={uploadedAssignment[key]?.regradedState == undefined || uploadedAssignment[key]?.regradedState} type="number" min="0" max="100" defaultValue={0} onChange={handleChange}
                            />
                                       
                        </td>
                        <td>
                        <Button style={{ display: 'flex', justifyContent: 'center', height: 30, width: 75 }} disabled={uploadedAssignment[key]?.regradedState == undefined || uploadedAssignment[key]?.regradedState} onClick={() => gradeByTeacher(key)}
                        >Send</Button>
                        </td>
                        </tr>
                            
                        </tbody>
                )})}
                <tfoot>
        
      </tfoot>
        </table>
        </div>
        </Menu.Menu>

        )
}

export default AssignmentsFromStudents;