//Bu dosyada ödev komponenti oluşturacağız.
//Bu komponenti ChatPanel içerisinde kullanacağız.
//Ödev komponenti, ödev gönderme ve ödev gönderilen ödevleri gösterme işlemlerini yapacak. userType öğretmen ise ödev gönderme, userType öğretmen ise ödev gönderme tuşu aktif olacak.
//Ödev gönderme tuşuna basıldığında ödev gönderme formu açılacak. Bu formda ödevin adı, ödevin açıklaması, ödevin tarihi, ödevin dosyası seçilecek. Bu formu gönder butonuna basıldığında ödev gönderilecek.

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Button, Form, Input, TextArea, Message, Icon, Modal } from 'semantic-ui-react';
import { useFirebase } from 'react-redux-firebase';


const TeacherLoadAssignment = () => {
    const firebase = useFirebase();
    const profile = useSelector(state => state.firebase.profile);
    const currentUserUid = useSelector(state => state.firebase.auth.uid);
    const userType = useSelector(state => state.firebase.profile.userType);
    const [homeworkName, setHomeworkName] = useState("");
    const [homeworkIsActive, setHomeworkIsActive] = useState(true);
    const currentChannel = useSelector((state) => state.channels.currentChannel);
    const [homeworkAttenders, setHomeworkAttenders] = useState([]);

    const [homeworkDescription, setHomeworkDescription] = useState("");
    const [homeworkDate, setHomeworkDate] = useState("");
    const [homeworkFile, setHomeworkFile] = useState("");
    const [homeworkFileUrl, setHomeworkFileUrl] = useState("");
    const [isDistributed, setIsDistributed] = useState(false);

    //set course code for assignment
    const [courseCode, setCourseCode] = useState("");

    const [open, setOpen] = useState(false);

    //isFileUploaded:
    //0: dosya yüklenmedi
    //1: dosya yükleniyor
    //2: dosya yüklendi
    const [isFileUploaded, setIsFileUploaded] = useState(0);

    //gönder butonuna basıldığında ödev gönderilecek ve firebase de Courses/Assignments kısmına eklenecek

    //currentChannel bilgisini almamız gerek. Böylece assignmentları bu kanalların altına yerleştireceğiz:
    
    const handleSubmit = (event) => {

        {console.log("SKK YER IKI DEFA NIYE YA ALO!!!")}
        firebase.push('courses/assignments', {
            homeworkName: homeworkName,
            homeworkIsActive: homeworkIsActive,
            homeworkDescription: homeworkDescription,
            homeworkDate: homeworkDate,
            homeworkFileUrl: homeworkFileUrl,
            homeworkAttenders: homeworkAttenders,
            courseCode: courseCode,
            isDistributed: isDistributed,
        });

        setHomeworkName("");
        setHomeworkDescription("");
        setHomeworkDate("");
        setHomeworkFileUrl("");
        setHomeworkIsActive(false);
        setHomeworkAttenders([]);
        setCourseCode("");
    };

    const uploadFile = (event) => {
        const file = event.target.files[0];
        if(file) {
            const storageRef = firebase.storage().ref();
            const fileRef = storageRef.child('course/assigment/${uuid()}'); // dosya adı ve uzantısı belirlenir
    
            return fileRef.put(file).then((snap) => {
                fileRef.getDownloadURL().then((downloadURL) => {

                    setHomeworkFileUrl(downloadURL);
                    setIsFileUploaded(2);
                    setCourseCode(currentChannel?.value?.courseCode);
                })
        })
        .catch((error) => {
            console.error("Error uploading file: ", error)});
    }};

    return (
        <div>
            
            {userType === "teacher" ? (
                
                <div>
                    <h1>Upload Homework</h1>
                    <div style={{height: "2px", backgroundColor: "gray", margin: "5px 0"}}></div>
                    <Modal trigger={<Button color="blue">Ödev Gönder</Button>} open={open} onOpen={() => setOpen(true)} onClose = {() => setOpen(false)}
                    >
                        <Modal.Header>Give Homework</Modal.Header>
                        <Modal.Content>
                            <Form >
                                <Form.Field>
                                    <label>Homework Name</label>
                                    <Input
                                        placeholder="Ödev Adı"
                                        value={homeworkName}
                                        onChange={(event) => setHomeworkName(event.target.value)}
                                    />
                                </Form.Field>
                                <Form.Field>
                                    <label>Ödev Açıklaması</label>
                                    <TextArea
                                        placeholder="Ödev Açıklaması"
                                        value={homeworkDescription}
                                        onChange={(event) => setHomeworkDescription(event.target.value)}
                                    />
                                </Form.Field>
                                <Form.Field>
                                    <label>Ödev Tarihi</label>
                                    <Input
                                        placeholder="Ödev Tarihi"
                                        value={homeworkDate}
                                        onChange={(event) => setHomeworkDate(event.target.value)}
                                    />
                                </Form.Field>
                                <Form.Field>
                                    <label>Ödev Dosyası</label>
                                    <Input
                                        type="file"
                                        placeholder="Ödev Dosyası"
                                        onChange={uploadFile}
                                    />
                                </Form.Field>
                                <Button
                                    color="blue"
                                    disabled={isFileUploaded === 0}
                                    onClick={() => {
                                        console.log("ÖDEV GÖNDERİLDİ");
                                        handleSubmit();
                                        setIsFileUploaded(0);
                                        setOpen(false);
                                    }}
                                >
                                    Gönder
                                </Button>
                            </Form>
                        </Modal.Content>
                    </Modal>
                </div>
            ) : (
                <div></div>
            )}
        </div>
    );
};


export default TeacherLoadAssignment;