//Bu sayfada coursepanel içerisindeki ödev kutularına dosya yükleyeceğiz.
//Yüklediğimiz dosyalar firebase deki courses/assignments/attenders kısmına eklenecek. Bu kısmı öncelikle oluşturacağız.
//Ödevi yükleyen öğrencinin ismi ve ödevi yüklediği tarih de eklenmeli.

import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useFirebaseConnect, isLoaded, isEmpty } from 'react-redux-firebase';
import { Button, Form, Input, TextArea, Message, Icon, Modal, Menu } from 'semantic-ui-react';
import { useFirebase } from 'react-redux-firebase';

const UploadAnswer = ({assignmentID}) => {
    const firebase = useFirebase();
    const profile = useSelector(state => state.firebase.profile);
    
    const currentUserUid = useSelector(state => state.firebase.auth.uid);
    useFirebaseConnect([ { path: `courses/assignments/${assignmentID}`,
                            storeAs: 'uploadedAssignment' } ]);


    const _homeworkAttenders = useSelector(state => state.firebase.data?.courses?.assignments?.[assignmentID]?.homeworkAttenders?.[currentUserUid]);

    const [objectionState , setObjectionState] = useState(false);
    const [isHomeworkCompleted, setIsHomeworkCompleted] = useState(false);
    const [homeworkFileUrl, setHomeworkFileUrl] = useState("");
    const [isFileUploaded, setIsFileUploaded] = useState(0);

    const uploadFile = (event) => {
        const file = event.target.files[0];
        if(file) {
            const storageRef = firebase.storage().ref();
            const fileRef = storageRef.child('course/assigment/${uuid()}'); // dosya adı ve uzantısı belirlenir
 

            return fileRef.put(file).then((snap) => {
                fileRef.getDownloadURL().then((downloadURL) => {
                    setHomeworkFileUrl(downloadURL);
                    const student = 
                    {
                        homeworkFileUrl: downloadURL,
                        homeworkDate: new Date().toLocaleString(),
                        homeworkIsActive: true,
                        isHomeworkCompleted: true,
                        objectionState: false,
                    }
                    firebase.push(`courses/assignments/${assignmentID}/homeworkAttenders/${currentUserUid}`, student);
                    setIsFileUploaded(2);
                    setIsHomeworkCompleted(true);
                    
                })
            
        })
        .catch((error) => {
            console.error("Error uploading file: ", error)});
    }};


    const deleteHomework = () => {
        firebase.remove(`courses/assignments/${assignmentID}/homeworkAttenders/${currentUserUid}`);
        setIsHomeworkCompleted(false);
        setIsFileUploaded(0);
    }


    return (
        <>
        <Button icon style={{marginBottom: "2em"}} disabled={_homeworkAttenders?.[Object.keys(_homeworkAttenders)?.[0]]?.isHomeworkCompleted} >
            <Icon
            name="add"
            />
            LOAD
            ANSWER 
            <Input type="file" name="file" onChange={uploadFile} />
        </Button>
        <Menu.Menu>

            {_homeworkAttenders?.[Object.keys(_homeworkAttenders)?.[0]]?.isHomeworkCompleted ? <Button icon style={{marginBottom: "2em"}} 
            //disabled={!isHomeworkCompleted} 
            
            onClick={deleteHomework}>
                <Icon
                    name="delete"
                />
                DELETE
                ANSWER
            </Button> : null}
            
        </Menu.Menu>
        </>
    );
}

export default UploadAnswer;

