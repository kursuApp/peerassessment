import React, { useState, useRef, useEffect } from 'react'
import { Segment, Header, Icon, Comment, Form, Input, Button } from 'semantic-ui-react'
import { useFirebase } from 'react-redux-firebase'
import { useSelector } from 'react-redux'
import { useFirebaseConnect, isLoaded, isEmpty } from 'react-redux-firebase'
import TeacherLoadAssignment from './TeacherLoadAssignment'
import AssignmentList from './AssignmentList'


const CoursePanel = ({ currentChannel }) => {
    console.log("currentChannel name: ", currentChannel); 
    useFirebaseConnect([ {path: `/messages/${currentChannel?.key}`,
                           storeAs: "/channelMessages",} 
                        ]);

return (
    <div style = {{ overflow: "auto", height: "100vh", backgroundColor: "#fff"}} 
    >
        
        <Segment clearing style={{ width: "100%", top:0,  backgroundColor: "#454545"}}>
            <Header as="h2" floated="left" color = "#5f1ef3" >
                <Icon name="hashtag" />
                {currentChannel?.value.name}
            </Header>
        </Segment>

        <TeacherLoadAssignment />

        <h1>Ödevler</h1>
        <div style={{height: "2px", backgroundColor: "gray", margin: "5px 0"}}></div>
        
        <AssignmentList />
            
        
        
    </div>
)
}

export default CoursePanel