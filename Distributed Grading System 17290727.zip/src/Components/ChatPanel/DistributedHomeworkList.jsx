//Bu safyada öğrencilere atanmış olan ödevleri listeleyeceğiz.

import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useFirebaseConnect, isLoaded, isEmpty } from 'react-redux-firebase';
import { Button, Form, Input, TextArea, Message, Icon, Modal, Menu } from 'semantic-ui-react';
import { useFirebase } from 'react-redux-firebase';

const DistributedHomeworkList = ({assignmentID}) => {
    const firebase = useFirebase();
    const profile = useSelector(state => state.firebase.profile);
    const currentUserUid = useSelector(state => state.firebase.auth.uid);
    useFirebaseConnect([ { path: `courses/assignments/${assignmentID.assignmentID}`,
                            storeAs: 'assignments' } ]);
    
    const currentAssignment = useSelector(state => state.firebase.data.courses.assignments[assignmentID]);

    const assignedNames = useSelector(state => state.firebase.data.courses.assignments[assignmentID].homeworkAttenders?.[currentUserUid]?.assignedNames);

    
    const distributeGradingState = useSelector(state => state.firebase.data.courses.assignments[assignmentID].homeworkAttenders?.[currentUserUid]?.distributeGrading);

    const receivedGrades = useSelector(state => state.firebase.data.courses.assignments[assignmentID].homeworkAttenders?.[currentUserUid]?.givenGrades);

    //assignedNames içerisindeki kullanıcı id lerini kullanarak o kullanıcıların ödevlerini çekeceğiz.

    //distributeGradingState undefined ise yazdıor:
    
    const downloadHomework = (Links) => {
        window.open(Links, '_blank');
    }


    const findHomeworkByUserId = (userId) => {
        //Bu user id ye sahip ödevi çekiyoruz:
        if (isLoaded(currentAssignment))
        {
            downloadHomework(Object.values(currentAssignment.homeworkAttenders?.[userId])[0].homeworkFileUrl);
        }
        
    }

    //assignedNames sayısına bağlı olarak bir genel puan tanımlayacağız. 
    //Derslerin geçme notunu 50 olarak belirliyoruz. Böylece puan veren öğrenciye
    //bakiye olarak {50 x assignedNames.length} kadar puan vereceğiz.
    //Inputları alırken sadece girilip girilmediğini değil,
    //girilen değerin 0-100 arasında olup olmadığını ve topamlarının bakiye
    //değerinden büyük olup olmadığını kontrol edeceğiz.
    //Aynı zamanda bakiye ekranda gösterilecek ve değerler canlı olarak,
    //input olarak girilen değerlere bağlı olarak güncellenecek.
    //Girilen değerler kime not verildiyse onun assignments/homeworkAttenders altındaki key değerine
    //eklenecek. Bu kayıt şu şekilde:
    /*
        {
            "grade": 50,
            "from": currentUserUid,
            "comment": "Harika bir ödev!
        }
        Bu infolarla birlikte bir kullanıcının ödevine kim tarafından kaç verildiği
        sistemde tutulacak. Final puanları da buradaki veriler üzerinden eğitilecek.
        
        Bir kullanıcı (EĞER ATAMALARDAKİ TÜM ÖĞRENCİLER NOT VERMİŞSE YANİ FİNAL NOTU OLUŞMUŞSA)
        son notuna itiraz edebilecek. Bunun için itiraz butonu herkesin puan vermesine bağlı olarak
        aktif olacak. Itiraz butonuna tıklandığında assignment sahibi öğretmenin itirazlar kısmına
        eklenecek. Bunun için homeworkAttenders altına objection boolean değeri eklenecek.Başlangıç değeri false.
        Öğretmenin itiraz listesi bu objection değerlerinin kontrollerinden oluşacak.
        Liste, objection = true olan öğrencilerin isimlerini ve ödevlerini öğretmene listede gösterecek.
        Öğretmen puan verip submit ettiğinde objection değeri false olacak ve oradaki ödev sahibi ve puanlandıran
        tüm öğrencilerin puanları güncellenecek.
    */
   
    
    const [grades, setGrades] = useState({});
    const [comments, setComments] = useState({});

    let totalGradeBalance = 0;
    let receivedGradesTotal = 0;

    let finalGrade = 0;

    const calculateFinalGrade = () => {
        //tum final grade i hesaplayacağız. Ayrıca burada penalty durumlarını da degerlendireceğiz.:

        //received grades içerisindeki grade değerlerini alalım:
        if (isLoaded(receivedGrades) && isLoaded(assignedNames) && isLoaded(currentAssignment)) {
            Object.values(receivedGrades).map((userId) => {
                
                finalGrade += parseInt(userId.grade);

            });
            finalGrade = finalGrade / Object.values(assignedNames).length;
            Object.values(assignedNames).map((userId) => {
                //objection ve regradedState değerlerini alalım:
                const objection = currentAssignment.homeworkAttenders?.[userId].objection;
                const regradedState = currentAssignment.homeworkAttenders?.[userId].regradedState;

                if (objection == true)  {
                    //objection true demektir.
                    //bu durumda regradedState değerini kontrol edelim:
                    if (regradedState && regradedState === false) {
                        //HENUZ HOCA TARAFINDAN DEGERLENDIRME YAPILMAMIS DEMEKTIR!
                    }
                    else {
                        //regradedState true demektir. Bu durumda gradeFromTeacher değeri oluşmuş demektir.
                        //Şimdi bu değeri alalım:
                        let gradeFromTeacher = currentAssignment.homeworkAttenders?.[userId].gradeFromTeacher;

                        //finalGrade i güncelleyelim:
                        //objectionun bulunduğu asignment içerisinde currentuserın verdiği puan ile hocanın verdiği puanın farkını buluyoruz:
                        let penalty = Math.abs(parseInt(currentAssignment.homeworkAttenders?.[userId]?.givenGrades?.[currentUserUid]?.grade) - parseInt(gradeFromTeacher));
                        finalGrade -= penalty;
                        //if final grade not NaN ise:
                        //ceza uygulandı!!!
                    }
                }
            });
            

        }
        return finalGrade;
        //ogrencilerden toplanan puanları aldık!
        //şimdi de penalty durumlarını hesaplayalım:

        /*
        Bunun için öncelikle assignedNames içerisindeki öğrenci keylerini alarak onların
        assignmentlarının içerisindeki  objection ve regradedState değerlerini alacağız.
        Eğer objection tanımlı değilse veya false ise finaGrade i güncelemeden yazdıracağız.
        Eğer objection true ise gradeFromTeacher değerini alacağız ve currentUserId (yani mevcut öğrenci) 
        tarafından verilen puanı bularak (ilgili assignmentin içerisindeki givenGrades kısmından alacağız)
        */

    }

    const objectionRequest = () => {
        if (isLoaded(currentAssignment))
        {
            //making objection request true
            firebase.update(`courses/assignments/${assignmentID}/homeworkAttenders/${currentUserUid}`, {objection: true});
            //regradedState = false;
            firebase.update(`courses/assignments/${assignmentID}/homeworkAttenders/${currentUserUid}`, {regradedState : false});
        }
    }
    const currentObjectionState = useSelector(state => state.firebase.data.courses?.assignments?.[assignmentID]?.homeworkAttenders?.[currentUserUid]?.objection);

    const handleSubmit = (e) => {
        e.preventDefault();

        console.log("Grades: ", grades);
        console.log("Comments: ", comments);

        for (let i = 0; i < Object.keys(grades).length; i++) {
            if (Object.values(comments)[i] == undefined)
            {
                const newGrade = {
                    grade: Object.values(grades)[i],
                    from: currentUserUid,
                    comment: ""
                }
                firebase.update(`courses/assignments/${assignmentID}/homeworkAttenders/${Object.keys(grades)[i]}/givenGrades/${currentUserUid}`, newGrade)
            }
            else 
            {
                const newGrade = {
                    grade: Object.values(grades)[i],
                    from: currentUserUid,
                    comment: Object.values(comments)[i]
                }
                firebase.update(`courses/assignments/${assignmentID}/homeworkAttenders/${Object.keys(grades)[i]}/givenGrades/${currentUserUid}`, newGrade)

            }
            
        }
  
    }

    
    //assignedNames kişi sayısı ile receivedGrades kişi sayısını karşılaştırıyoruz:
    //eğer eşitse tüm öğrenciler not vermiş demektir.
    const isAllGraded = () => {
        if (isLoaded(assignedNames) && isLoaded(receivedGrades)) {
            if (Object.keys(assignedNames).length == Object.keys(receivedGrades).length) {
                return true;
            }
            else {
                return false;
            }
        }
    }

    return (
        <>
        <table style={{backgroundColor: "gray"}}>
            <thead>
                <tr>
                    <th>Homework</th>
                    <th>Grade</th>
                    <th>Comment</th>
                </tr>
            </thead>
            {
                isLoaded(assignedNames) && Object.values(assignedNames).map((userId) => {
                    console.log("userId: ", userId);
                    return (
                                             
                        <tbody>
                            <tr>
                                <td>
                                    <Button onClick={() => findHomeworkByUserId(userId)}>Ödevi Göster</Button>
                                </td>
                                <td>
                                    <input type="number" min="0" max="100" defaultValue={0}
                                    onChange={(e) => setGrades({ ...grades, [userId]: e.target.value })} />
                                </td>
                                <td >
                                    <input type="TextArea" placeholder='Write Comments' defaultValue={""}
                                    onChange={(e) => setComments({ ...comments, [userId]: e.target.value })}/>
                                </td>
                                
                            </tr>
                            
                        </tbody>
                        

                    )
                })
            }
            
            <tfoot>
        <tr>
          <td colspan="2">
            <button onClick={handleSubmit} disabled = {distributeGradingState == true}>Submit</button>
          </td>
        </tr>
      </tfoot>
        </table>
            <div>

                {
                    Object.values(grades).map((grade) => {
                        totalGradeBalance += parseInt(grade);
                        console.log("totalGradeBalancesss: ", totalGradeBalance);
                        
                    })
                }
                <h1>
                    Balance: 
                {
                    
                    isLoaded(assignedNames) && (Object.values(assignedNames).length * 50) - totalGradeBalance

                }</h1>
            </div>
            <div style={{height: "2px", backgroundColor: "black", margin: "10px 0"}}></div>
            <div>
                <h2>Puanlar: </h2>
            </div>
            
            {
                //burada kullanıcının diğer öğrencilerden aldıkları puanları listeleyeceğiz.
                isAllGraded() && isLoaded(receivedGrades) && Object.values(receivedGrades).map((userId) => {
                    console.log("userId: ", userId.grade);
                    
                    receivedGradesTotal += parseInt(userId.grade);
                    return (
                        <>
                        <table> 
                            <thead>
                                <tr>
                                    <th>Grade</th>
                                    <th>Comment</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        {userId.grade}
                                    </td>
                                    <td>
                                        {userId.comment}
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                        
                        </>
                        
                    );

                })
                
            }
            <div style={{textAlign: 'center'}}>
                <h1> Total Grade: {calculateFinalGrade()}</h1>
                {
                    //is passed or not
                    isAllGraded() && receivedGradesTotal / Object.values(receivedGrades).length >= 50 ? <h1>Passed</h1> : <h1> Failed</h1>
                }
            </div>
            <div>
                {/* objection button we will set Objection to true if clicked*/ }
                <Button onClick={objectionRequest} disabled = {(currentObjectionState == true) || (currentObjectionState != undefined)}
                >Objection Request</Button>
                
            </div>
        </>
        
    )
    }
export default DistributedHomeworkList;
