//Bu kısımda firebasedeki assigmentları alıyoruz ve her bir assigment için bir ödev kutusu oluşturarak bu kutunun içerisine assigment bilgilerini yazıyoruz.

import { useSelector } from 'react-redux';
import React, { useState, useEffect } from 'react';
import { useFirebaseConnect, isLoaded, isEmpty, useFirebase } from 'react-redux-firebase';
import { Menu } from 'semantic-ui-react'
import UploadAnswer from './UploadAnswer';
import AssignmentsFromStudents from './AssignmentsFromStudents'
import DistributedHomeworkList from './DistributedHomeworkList';

const AssignmentList = () => {
    useFirebaseConnect([ {path: 'courses'} ])
    const assignments = useSelector(state => state.firebase.data.courses?.assignments);
    const userType = useSelector(state => state.firebase.profile.userType);
    const currentChannel = useSelector((state) => state.channels.currentChannel);
    const firebase = useFirebase();
    const [numAssignments, setNumAssignments] = useState(0);


    //get assignment key and make isDistributed true
    const makeDistributed = (key) => {
        firebase.update(`courses/assignments/${key}`, {isDistributed: false});

    }

    //Herbir assignment içersindeki attendersları alıyoruz.
    //Ardından bu attendersların içerisine numAssignments kadar sayıda diğer ödevlerden dağıtacağız.

    const distributeAssignments = (key) => {
        //numAssignments olarak direkt numAssignments state kullanacağız.
        //names listemiz zaten attenders içerisindeki isimler.
        
        const AttendersCount = Object.keys(assignments[key].homeworkAttenders).length;

        for(let i = 0; i<AttendersCount; i++)
        {
            const assignedNames = [];
            for(let j=0; j<numAssignments; j++)
            {
                const index = (i+j+1) % AttendersCount;
                assignedNames.push(Object.keys(assignments[key].homeworkAttenders)[index]);
            }
            firebase.update(`courses/assignments/${key}/homeworkAttenders/${Object.keys(assignments[key].homeworkAttenders)[i]}`, {assignedNames: assignedNames});
        }
    }

    //olası hatalarda atamaları değiştirmek için bu kısma silme fonksiyonu yazacağız:


    //asignment içerisindeki homeworkAttenders içerisinde eğer currentUserUid varsa ödevi yüklemiş demektir.
    const currentUserUid = useSelector(state => state.firebase.auth.uid);
    const homeworkDone = false
    
    
    const handlechange = (e) => {
        setNumAssignments(e.target.value);
    }
    const handleClick = (key) => {
        setNumAssignments(0);
        makeDistributed(key);
        distributeAssignments(key);
        //console.log("BU KEYI ALABILIYOZ MU KAASDAS: ", key);

    }

    //eğer isDistriuted true dağıt buton kısmını kaldırıyoruz.

    //assigmentların her birisi için bir ödev kutusu oluşturuyoruz.
    return (

        <Menu.Menu >
            {
                
                assignments && Object.keys(assignments).map((key) => {
                    
                    if (assignments[key].courseCode != currentChannel?.value?.courseCode )
                        return null;
                    
                    //kullanıcının kayıtlı olduğu ödevse zaten okey 👌

                    return <div key={key} style={{marginBottom: "2em", 
                                                  borderStyle: "dashed",
                                                  padding: "1em", 
                                                  backgroundColor: "#989898", 
                                                  display: "flex", 
                                                  flexDirection: "column", 
                                                  alignItems: "center"}}>
                        {userType == "teacher" && <div>
                            <h1> {/* input elementi */}
                            <input type="number" value={numAssignments} onChange={handlechange} />
                            
                            <button onClick={() => handleClick(key)}>Distribute</button></h1>
                            
                            
                        </div>}
                        <Menu.Item 
                            name={"Homework  " + assignments[key].homeworkName} 
                            as="a"
                            icon="file"
                            //add homeworkDescription
                            description={assignments[key].homeworkDescription}
                            disabled={assignments[key].homeworkIsActive == false}
                            //go to downloadlink when onclick
                            onClick={() => window.open(assignments[key].homeworkFileUrl)}
                            style={{backgroundColor: "#001100", 
                            width: "100%", 
                            padding: "20px 30px", 
                            fontSize: "1.4em", 
                            color: "white"}}
                        
                        />
                        <div style={{height: "2px", margin: "5px 0"}}></div>
                        {userType == "student" ? <UploadAnswer assignmentID={key} />: null}
                        <div style={{marginBottom: "2em"}}>
                        {userType == "teacher" ? <AssignmentsFromStudents assignmentID={key} /> : null}
                        </div>
                        
                        <div style={{marginBottom: "2em"}}>
                        {userType == "student" ? <AssignmentsFromStudents assignmentID={key} /> : null}
                        </div>

                        {/*Buraya distributed homeworks ekleyeceğiz::*/}
                        {userType == "student" ? <DistributedHomeworkList assignmentID={key} /> : null}
                        
                    </div>
                    
                })
            }
        </Menu.Menu>
    )

}

export default AssignmentList;