import React, {useState, useEffect } from 'react'
import { useFirebaseConnect, isLoaded, isEmpty } from 'react-redux-firebase'
import { useSelector, useDispatch } from 'react-redux'
import { setCurrentCourse  } from '../../Store/actions/channel'
import { Menu } from 'semantic-ui-react'


const CourseList = () => {

    useFirebaseConnect([ {path: 'courses'} ])

    useFirebaseConnect([ {path: 'users'} ])
    const dispatch = useDispatch();

    const courses = useSelector(state => state.firebase.ordered.courses);

    const currentChannel = useSelector(state => state.channels?.currentChannel);
    
    //Current userdan yola çıkarak onda tanımlı olan dersleri filtreleyip listeleyeceğiz.
    const currentUserUid = useSelector(state => state.firebase.auth.uid);

    //to get current user datas from firebase
    const currentUserDatas = useSelector(state => state.firebase.data?.users?.[currentUserUid]);
    const [mounted, setMounted] = useState(false); 

    useEffect(() => {
        if (!mounted && !isEmpty(courses)) {
            //const { key, value } = courses[0];
            //Buradaki sorun, courses[0] un, current user ın ders listesinde olup olmadığını kontrol etmemiz gerekiyor.
            //if currentUserDatas.courseList has not the value.courseCode, then do not show the course.
            //current user ın ders listesi alıyoruz bu listenin ilk elemanını course dan bulup onu set ediyoruz.
            let courseToActive = courses[0];
            //aktif edilecek olan course kodu
            for (let i = 0; i < courses.length; i++) {
                if (courses[i].value.courseCode === currentUserDatas.courseList[0]) {
                  courseToActive = courses[i];
                }}
                const { key, value } = courseToActive;
              
            setActiveChannel({ key, value });
            dispatch(setCurrentCourse({ key, value }));
            setMounted(true);
        }
    }, [isLoaded(currentUserDatas) && isLoaded(courses)]);

    const setActiveChannel = (channel) => {

        dispatch(setCurrentCourse(channel))
    }

    if (!isLoaded(courses)  && !isLoaded(currentUserDatas)) {
        return <div>Loading...</div>
    }
    if (isEmpty(courses)) {
        return <div>No Channel</div>
    }
  return (
<Menu.Menu>
  {
    courses.map(({key, value}) => {
        //bu noktada ödevleri currentId içerisindeki ders listesinde var mı diye kontrol ederek göstereceğiz.
        //if currentUserDatas.courseList has not the value.courseCode, then do not show the course.
        if (!currentUserDatas?.courseList.includes(value.courseCode)) {
            return null;
        }
        return <Menu.Item 
        key={key}
        name={value?.courseName + " - " + value?.courseCode}
        as="a"
        icon="hashtag"
        active={currentChannel?.key === key}
        onClick={() => setActiveChannel({key, value})}
        style={{ 
          borderBottom: "1px solid gray",
          backgroundColor: "#2f2f2f",
          fontSize: "1em",
          color: "white",
          position: "relative"
        }}
      />
    })
  }
</Menu.Menu>

  )
}

export default CourseList