import React , { useEffect }from 'react'
import { useSelector } from 'react-redux'
import {useForm } from 'react-hook-form'
import { Modal, Form, Button} from 'semantic-ui-react'
import { useFirebase } from 'react-redux-firebase'


const CreateCourseForm = ({open, onOpen, onClose}) => {
    const firebase = useFirebase();
    const profile = useSelector(state => state.firebase.profile);
    
    const { register, formState: {errors}, handleSubmit, setValue } = useForm();

    useEffect(() => {
        register({ name: "name" }, { required: true , minLength: 2});
        register({ name: "description" }, { required: true , minLength: 2});
    }, []);

    const onSubmit = ( {name, description}, e) => {
        firebase.push('courses', {
            name, 
            description,
            assigment: [],
            createdBy: {
                name: profile.name, 
                avatar: profile.avatar
            }});
        
            onClose();
        
    };

  return (
    <Modal open={open} onOpen={onOpen} onClose={onClose}>
        <Modal.Header>Create a New Course</Modal.Header>
        <Modal.Content>
            <Form onSubmit = {handleSubmit(onSubmit)}>
                <Form.Input
                fluid
                icon="hashtag"
                iconPosition="left"
                name="name"
                placeholder="Course Name"
                onChange={(e, {name, value}) => setValue(name, value)}
                error = {errors.name ? true : false}

                />
                <Form.Input
                fluid
                icon="hashtag"
                iconPosition="left"
                name="description"
                placeholder="Course Description"
                onChange={(e, {name, value}) => setValue(name, value)}
                error = {errors.description ? true : false}
                />
            </Form>
        </Modal.Content>

        <Modal.Actions>
            <Button color="green"
                    onClick={() => handleSubmit(onSubmit) ()}>
                Create
            </Button>
            <Button color="red"
                    onClick={() => onClose()}>
                Cancel
            </Button>
            
        </Modal.Actions>
    </Modal>

  )
}

export default CreateCourseForm