import React, {useState } from "react";
import { Popup, Menu, Icon } from "semantic-ui-react";
import CreateCourseForm from "../Channels/CreateCourseForm";
import { useSelector } from 'react-redux'
import CourseList from "../Channels/CourseList";
import { useFirebase } from 'react-redux-firebase'
import './sidePanel.css'

const SidePanel = () => {

    const firebase = useFirebase();

    const profile = useSelector(state => state.firebase.profile);
    
    const currentChannel = useSelector(state => state.channel?.currentChannel);

    const signOut = () => {
        //currentChannel = null;
        firebase.logout();

    }

    return (
 
        <Menu
            width="3"
            vertical
            
            style={{

                top: 0,
                left: 0,
                margin: 0,

                width: "100%",
                //position : "fixed",
                fontSize: "1.3rem",
                backgroundColor: "#ddd",
                height: "100%",
                
                overflowY: "auto"
            }}

        >
            <Menu.Item style={{ width: "100%", backgroundColor: "#454545" }}>

                { /* user panel*/}
                <div className="userP" backgroundColor="00f" style={{textAlign: "center"}} >
                    
                    <p>{profile?.name}</p>
                    <div>
                        {<Icon name="sign out" onClick={() => signOut()} />}
                    </div>
                </div>

            </Menu.Item>
            <Menu.Item style={{ height:"100%", width: "100%", backgroundColor: "#ffeedd" }}>
                <Menu.Header>
                    Courses
                </Menu.Header>
                <CourseList />
            </Menu.Item>
            
        </Menu>

        
        
    );
};


export default SidePanel;