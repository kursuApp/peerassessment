import React, { useState, useEffect } from 'react'
import { useForm } from "react-hook-form"
import { useFirebase } from 'react-redux-firebase'
import { Form, Segment, Button, Grid, Message } from 'semantic-ui-react'
import styles from "./signup.module.css"

const Signup = () => {

    const firebase = useFirebase();

    const { register, formState: {errors}, handleSubmit, setValue } = useForm();

    const [fbErrors, setFbErrors] = useState([]);
    const [submitting, setSubmitting] = useState(false);

    const [userType, setUserType] = useState('student');

    //kayıt yapılan tür öğretmen olduğunda:
    //bu öğretmen için bir ders listesi oluşturulacak.
    
    //create simple course list object for teacher and each corse has COM4000 as default and taken is false

    const courseListArray = [

        {
            courseCode: "COM4513",
            courseName: "Computer Networks",
            taken: false
        },


        {
            courseCode: "COM4514",
            courseName: "Computer Networks Lab",
            taken: false

        },
        {
            courseCode: "COM4515",
            courseName: "Introduction to Database Systems",
            taken: false
        }
    ]
    //change first element taken value to true

    //create a function to add course list to database
    const handleUserTypeChange = (event) => {
        setUserType(event.target.value);
        }
    
    useEffect(() => {
        
        register({ name: "username" }, { required: true });
        register({ name: "email" }, { required: true});
        register({ name: "password" }, { required: true , minLength: 6});
});

    const onSubmit = ( {username, email, password}, e) => {
        setSubmitting(true);
        setFbErrors([]);
        
        const [first, last] = username.split(' ');
        console.log("email: ", email)
        console.log("password", password)
        firebase.createUser(
            { email, password },
            { 
                
                name: username,
                avatar: 'https://ui-avatars.com/api/?name={'+ first +'}+{'+ last + '}&background=random&color=fff&',
                userType: userType,
                courseList: ["COM4514", "COM4515"]
                
            }).then((user) => {
                console.log(user)
                

            }).catch((error) => {
                setFbErrors([{message: error.message}]);
                
            }).finally(() => {
                setSubmitting(false);
            } 
            );
    
    };

    const displayErrors = () => fbErrors.map((error, index) => <p key={index}>{error.message}</p>);
     return (
    <Grid 
    textAlign="center" 
    verticalAlign="middle"
    className={styles.container}>
    <Grid.Column style={{maxWidth: 450}}>  
        <h1 className={styles.formHeader}> Chatify 
        <span>.io</span>
        </h1>
        
        <Form 
        size="large"
        className={styles.form}
        onSubmit={handleSubmit(onSubmit)}
        >
            <Segment>
                {/*  User type selection: */}
                <div className={styles.userType}>
                    <label>
                        <input
                            type="radio"
                            name="userType"
                            value="student"
                            checked={userType === 'student'}
                            onChange={handleUserTypeChange}
                        />
                        Öğrenci
                    </label>
                    {/*  interval between two options */}
                    <div className={styles.interval}></div>
                    <label>
                        <input
                            type="radio"
                            name="userType"
                            value="teacher"
                            checked={userType === 'teacher'}
                            onChange={handleUserTypeChange}
                        />
                         Öğretmen
                    </label>
                </div>
                {/*  User type selection: */}
                
                <Form.Input 
                fluid icon="user" 
                iconPosition='left' 
                name="username"
                onChange={(event, {name, value}) => setValue(name, value)}
                error={errors.username ? true : false}
                placeholder = "Kullanıcı Adı"
                type = "text"
                />
                <Form.Input 
                fluid icon="mail" 
                iconPosition='left' 
                name="email"
                onChange={(event, {name, value}) => setValue(name, value)}
                error={errors.email ? true : false}
                placeholder = "Email Adresi"
                type = "email"
                
                />   
                <Form.Input 
                fluid icon="lock" 
                iconPosition='left' 
                name="password"
                onChange={(event, {name, value}) => setValue(name, value)}
                error={errors.password ? true : false}
                placeholder = "Sifre"
                type="password"
                
                />
                <Button color='purple' fluid size='large' disabled={submitting}>
                    Kaydol
                </Button>
                </Segment>
        </Form>
        {fbErrors.length > 0 && <Message error> {displayErrors()}</Message>}
        <Message>
            <a href="/login">Giris</a>
        </Message>
        
        </Grid.Column>
    </Grid>
    
  )
}

export default Signup