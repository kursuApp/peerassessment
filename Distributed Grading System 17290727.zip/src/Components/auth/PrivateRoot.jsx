import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { isLoaded, isEmpty } from 'react-redux-firebase';
import { useSelector } from 'react-redux';

import Fallback from './Fallback';

const PrivateRoot = () => {
    const auth = useSelector(state => state.firebase.auth)
    return (
        isLoaded(auth) && !isEmpty(auth) ? <Outlet /> : <Fallback/>

      )
}

export default PrivateRoot