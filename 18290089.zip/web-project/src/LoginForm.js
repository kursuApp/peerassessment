import React, { useState } from 'react';
import StudentDashboard from './Student/StudentDashbord';
import ExpertDashboard from './Expert/ExpertDashbord';
const LoginForm = () => {
    // Use state to store the login form data
    const [formData, setFormData] = useState({
        username: '',
        password: '',
        userType: 'student'
    });

    // Use state to store the logged in user
    const [loggedInUser, setLoggedInUser] = useState(null);

    // Function to handle form input changes
    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData((formData) => ({
            ...formData,
            [name]: value
        }));
    };

    // Function to handle form submission
    const handleSubmit = (event) => {
        event.preventDefault();

        localStorage.setItem('loggedInUser', JSON.stringify(formData));
        setLoggedInUser(formData);
    };

    // If a user is already logged in, redirect them to the appropriate page
    if (loggedInUser) {
        if (loggedInUser.userType === 'student') {
            return <StudentDashboard />;
        }
        if (loggedInUser.userType === 'expert') {
            return <ExpertDashboard />;
        }
    }

    // If no user is logged in, show the login form
    return (
        <form onSubmit={handleSubmit}>
            <label>
                Username:
                <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                />
            </label>
            <br />
            <label>
                Password:
                <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                />
            </label>
            <br />
            <label>
                User Type:
                <select
                    name="userType"
                    value={formData.userType}
                    onChange={handleChange}
                >
                    <option value="student">Student</option>
                    <option value="expert">Expert</option>
                </select>
            </label>
            <br />
            <input type="submit" value="Log In" />
        </form>
    );
};


export default LoginForm;