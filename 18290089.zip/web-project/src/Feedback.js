export const Feedback = [

    {
        id: 1,
        feed: "can you control my Homework 1 number:123456"
    },
    {
        id: 2,
        feed: "could you control my homework 3 number:123458"
    },


];