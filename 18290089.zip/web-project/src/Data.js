
export const Data = [
    {
        name: "Jennie",
        number: "123456",
        grade: 0,

    },
    {
        name: "Alex",
        number: "123457",
        grade: 0,


    },
    {
        name: "John",
        number: "123458",
        grade: 0,

    },
    {
        name: "Lisa",
        number: "123459",
        grade: 0,

    }

];
