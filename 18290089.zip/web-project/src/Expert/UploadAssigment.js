
import React, { useState } from 'react'

const UploadAssigment = () => {

    const [assignments, setAssignments] = useState([]);
    const addAssignment = (assignment) => {
        setAssignments([...assignments, assignment]);
    };
    const handleSubmit = (event) => {
        event.preventDefault();

    }


    return (
        <div>

            <form onSubmit={(e) => {
                e.preventDefault();
                addAssignment({ id: assignments.length + 1, name: e.target.elements.name.value });
            }}>
                <input type="text" name="name" placeholder="Assignment name" />
                <button type="submit">Add Assignment</button>
            </form>
            <form onSubmit={handleSubmit}>
                <input type="file" id="file-input" />
                <button type="submit">Upload Assignment</button>

            </form>
            <ul>
                {assignments.map((assignment) => (
                    <li key={assignment.id}>
                        {assignment.name}
                    </li>
                ))}
            </ul>
        </div>
    );

}

export default UploadAssigment;