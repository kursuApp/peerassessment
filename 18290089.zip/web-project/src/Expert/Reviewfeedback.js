import React from 'react'
import { Feedback } from '../Feedback';

const Reviewfeedback = () => {
    return (
        <div>
            <ul>
                {Feedback.map((ee) => (
                    <li key={ee.id}>
                        {ee.feed}
                    </li>
                ))}
            </ul>
        </div>
    )
};

export default Reviewfeedback;