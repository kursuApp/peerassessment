import React from 'react'
import { Link } from 'react-router-dom';

const NavbarExpert = () => {
    return (
        <nav>
            <ul>
                <li>
                    <Link to="/UploadAssigment">UploadAssigment </Link>
                </li>
                <li>
                    <Link to="/ReviewFeedback">ReviewFeedbacks </Link>
                </li>
                <li>
                    <Link to="/AdjustTotalScore">AdjustTotalScore </Link>
                </li>


            </ul>
        </nav>
    )
}

export default NavbarExpert