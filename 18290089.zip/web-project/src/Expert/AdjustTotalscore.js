import React from 'react'

const AdjustTotalscore = () => {
    return (
        <div>AdjustTotalscore</div>
    )
}

export default AdjustTotalscore;