import React from 'react';
import { Routes, Route } from 'react-router-dom';
import NavbarExpert from './NavbarExpert';
import UploadAssigment from './UploadAssigment';
import Reviewfeedback from './Reviewfeedback';
import AdjustTotalscore from './AdjustTotalscore';
const ExpertDashbord = () => {

    const username = localStorage.getItem('loggedInUser');
    const data = JSON.parse(username);

    return (
        <div>
            <h1>Welcome, {(data.username)}</h1>
            <p>You are logged in as a Expert.</p>
            <NavbarExpert />
            <Routes>

                <Route path="/UploadAssigment" element={<UploadAssigment />} />
                <Route path="/ReviewFeedBack" element={<Reviewfeedback />} />
                <Route path="/AdjusttotalScore" element={<AdjustTotalscore />} />

            </Routes>
        </div>
    );
};
export default ExpertDashbord;