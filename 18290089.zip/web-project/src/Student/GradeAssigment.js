import React from 'react'
import { useState } from 'react';
import { Data } from "../Data"

const GradeAssigment = () => {
    const [selectedAssignment, setSelectedAssignment] = useState("");
    const [grade, setGrade] = useState("");

    const handleSubmit = (event) => {
        event.preventDefault();
        // Update the assignment object with the new grade
        Data[selectedAssignment].grade = grade;
        // Reset the form fields
        setSelectedAssignment("");
        setGrade("");
    };

    return (
        <form onSubmit={handleSubmit}>
            <label htmlFor="assignment-select">Assignment:</label>
            <select
                id="assignment-select"
                value={selectedAssignment}
                onChange={(event) => setSelectedAssignment(event.target.value)}
            >
                <option value="">Select an assignment</option>
                {Object.keys(Data).map((assignment) => (
                    <option value={assignment}>{assignment}</option>
                ))}
            </select>
            <br />
            <label htmlFor="grade-input">Grade:</label>
            <input
                id="grade-input"
                type="number"
                value={grade}
                onChange={(event) => setGrade(event.target.value)}
            />
            <br />
            <button type="submit">Submit</button>
        </form>
    );
}


export default GradeAssigment;