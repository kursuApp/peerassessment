import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Navbar from './Navbar';
import SubmitAssigment from './SubmitAssigment';
import ObjectGrading from './ObjectGrading';
import GradeAssigment from './GradeAssigment';
import ReviewGrade from './ReviewGrade';

const StudentDashboard = () => {

    const username = localStorage.getItem('loggedInUser');
    const data = JSON.parse(username);

    return (

        <div>
            <h1>Welcome, {(data.username)}</h1>
            <p>You are logged in as a Student.</p>
            <Navbar />
            <Routes>

                <Route path="/SubmitAssigment" element={<SubmitAssigment />} />
                <Route path="/ObjectGrading" element={<ObjectGrading />} />
                <Route path="/GradeAssigment" element={<GradeAssigment />} />
                <Route path="/ReviewGrade" element={<ReviewGrade />} />


            </Routes>

        </div>

    );
};

export default StudentDashboard;