import React from 'react'

import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <nav>

            <ul>
                <li>
                    <Link to="/SubmitAssigment">SubmitAssigment </Link>
                </li>
                <li>
                    <Link to="/ObjectGrading">ObjectGrading</Link>
                </li>
                <li>
                    <Link to="/GradeAssigment">GradeAssigment</Link>
                </li>
                <li>
                    <Link to="/ReviewGrade">ReviewGrade</Link>
                </li>

            </ul>
        </nav>
    )
};

export default Navbar;