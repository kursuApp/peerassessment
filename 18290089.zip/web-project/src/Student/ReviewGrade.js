import React from 'react'
import { Data } from '../Data';
const ReviewGrade = () => {
    return (
        <div>
            <ul>
                <p>{Data[1].name}  {Data[1].grade}  </p>
            </ul>

        </div>
    )
}

export default ReviewGrade;
