import React, { useState } from 'react'



const SubmitAssigment = () => {

    const [assignment, setAssignment] = useState({
        file: null
    });

    const handleChange = (event) => {
        const { name, value, files } = event.target;
        if (name === 'file') {
            setAssignment({ ...assignment, file: files[0] });
        } else {
            setAssignment({ ...assignment, [name]: value });
        }
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(assignment);
        // here you could handle the submission of the assignment, such as sending it to a server or storing it locally
    }

    return (
        <form onSubmit={handleSubmit}>
            <label htmlFor="file">File:</label>
            <input type="file" name="file" onChange={handleChange} />
            <br />
            <button type="submit">Submit Assignment</button>
        </form>
    );

}

export default SubmitAssigment;