import React from 'react'
import { useState } from 'react';
import { Feedback } from '../Feedback';
const ObjectGrading = () => {
    const [feedback, setfeedback] = useState([]);
    const addfeedback = (e) => {
        setfeedback([...feedback, e]);
        Feedback.push(e)
    };


    return (
        <div>

            <form onSubmit={(e) => {
                e.preventDefault();
                addfeedback({ id: feedback.length + 1, name: e.target.elements.name.value });
            }}>
                <input type="text" name="name" placeholder="feedback name" />
                <button type="submit">Add feedback</button>
            </form>
            <ul>
                {feedback.map((e) => (
                    <li key={e.id}>
                        {e.name}
                    </li>
                ))}
            </ul>
        </div>
    );

}


export default ObjectGrading;