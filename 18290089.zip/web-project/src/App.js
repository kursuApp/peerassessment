
import './App.css';
import LoginForm from './LoginForm';
import { BrowserRouter as Router, Route, Routes, BrowserRouter } from 'react-router-dom';




function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <header className="App-header">
          <h1> Grading system</h1>
          <LoginForm></LoginForm>
        </header>
      </div>
    </BrowserRouter>

  );
}

export default App;
